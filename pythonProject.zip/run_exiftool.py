
import tkinter as tk
from tkinter import filedialog
import os
import csv
from exiftool import ExifTool
from tqdm import tqdm
import chardet

root = tk.Tk()
root.withdraw()
metadata_names = ['r', 'FileName','CreateDate', 'By-line', 'Caption-Abstract', 'Subject']

input("Bonjour ! Appuyez sur Entrée pour choisir le dossier")
dir_path = filedialog.askdirectory()
print("Répertoire choisi : ", dir_path)

with ExifTool() as et:
    data = et.execute_json(*['-r', '-FileName', '-CreateDate', '-By-line',
                                            '-Description', '-Subject', '-charset UTF-8'] + [dir_path])
    print(data)

