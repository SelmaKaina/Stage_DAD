import sys
import json
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QLabel, QLineEdit, QVBoxLayout, QWidget, QPushButton, QCheckBox, QFileDialog,
    QHBoxLayout, QTextEdit, QGridLayout, QScrollArea
)
from PyQt6.QtCore import Qt

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Formulaire avec Champs Optionnels")

        # Style pour l'ensemble de l'application
        self.setStyleSheet("""
            background-color: #f0e68c;
            font-size: 12px;
            font-family: Arial;
            padding: 10px;
        """)

        # Texte introductif
        intro_label = QLabel("Veuillez remplir le formulaire ci-dessous :")
        intro_label.setStyleSheet("color: #8b4513;")
        intro_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Créer les widgets pour les champs de texte existants
        self.num_entree = QLabel("Numéro de l'entrée :")
        self.num_entree.setStyleSheet("color: #8b4513;")
        self.entree_input = QLineEdit()

        self.num_paquet = QLabel("Numéro du paquet :")
        self.num_paquet.setStyleSheet("color: #8b4513;")
        self.paquet_input = QLineEdit()

        self.versement_label = QLabel("Intitulé du versement :")
        self.versement_label.setStyleSheet("color: #8b4513;")
        self.versement_input = QLineEdit()

        # Ajouter les nouveaux champs requis

        self.archival_agency_identifier_label = QLabel("ArchivalAgency Identifier :")
        self.archival_agency_identifier_label.setStyleSheet("color: #8b4513;")
        self.archival_agency_identifier_input = QLineEdit()

        self.transferring_agency_identifier_label = QLabel("TransferringAgency Identifier :")
        self.transferring_agency_identifier_label.setStyleSheet("color: #8b4513;")
        self.transferring_agency_identifier_input = QLineEdit()

        self.originating_agency_identifier_label = QLabel("OriginatingAgency Identifier :")
        self.originating_agency_identifier_label.setStyleSheet("color: #8b4513;")
        self.originating_agency_identifier_input = QLineEdit()

        self.submission_agency_identifier_label = QLabel("SubmissionAgency Identifier :")
        self.submission_agency_identifier_label.setStyleSheet("color: #8b4513;")
        self.submission_agency_identifier_input = QLineEdit()

        self.authorized_agent_activity_label = QLabel("AuthorizedAgent Actvity :")
        self.authorized_agent_activity_label.setStyleSheet("color: #8b4513;")
        self.authorized_agent_activity_input = QLineEdit()

        self.authorized_agent_mandate_label = QLabel("AuthorizedAgent Mandate :")
        self.authorized_agent_mandate_label.setStyleSheet("color: #8b4513;")
        self.authorized_agent_mandate_input = QLineEdit()

        self.archival_profile_label = QLabel("ArchivalProfile :")
        self.archival_profile_label.setStyleSheet("color: #8b4513;")
        self.archival_profile_input = QLineEdit()

        self.acquisition_information_label = QLabel("AcquisitionInformation :")
        self.acquisition_information_label.setStyleSheet("color: #8b4513;")
        self.acquisition_information_input = QLineEdit()

        self.legal_status_label = QLabel("Legal Status :")
        self.legal_status_label.setStyleSheet("color: #8b4513;")
        self.legal_status_input = QLineEdit()

        # Cases à cocher pour les valeurs à sélectionner
        self.metadata_checkboxes = []
        createdate = QCheckBox(f"-CreateDate")
        createdate.setStyleSheet("color: #8b4513;")
        self.metadata_checkboxes.append(createdate)

        modifdate = QCheckBox(f"-FileModifyDate")
        modifdate.setStyleSheet("color: #8b4513;")
        self.metadata_checkboxes.append(modifdate)

        by_line = QCheckBox(f"-By-line")
        by_line.setStyleSheet("color: #8b4513;")
        self.metadata_checkboxes.append(by_line)

        artist = QCheckBox(f"-Artist")
        artist.setStyleSheet("color: #8b4513;")
        self.metadata_checkboxes.append(artist)

        creator = QCheckBox(f"-Creator")
        creator.setStyleSheet("color: #8b4513;")
        self.metadata_checkboxes.append(creator)

        city = QCheckBox(f"-City")
        city.setStyleSheet("color: #8b4513;")
        self.metadata_checkboxes.append(city)

        country = QCheckBox(f"-Country")
        country.setStyleSheet("color: #8b4513;")
        self.metadata_checkboxes.append(country)

        country_pln = QCheckBox(f"-Country-PrimaryLocationName")
        country_pln.setStyleSheet("color: #8b4513;")
        self.metadata_checkboxes.append(country_pln)

        caption = QCheckBox(f"-Caption-Abstract")
        caption.setStyleSheet("color: #8b4513;")
        self.metadata_checkboxes.append(caption)

        description = QCheckBox(f"-Description")
        description.setStyleSheet("color: #8b4513;")
        self.metadata_checkboxes.append(description)

        subject = QCheckBox(f"-Subject")
        subject.setStyleSheet("color: #8b4513;")
        self.metadata_checkboxes.append(subject)

        keywords = QCheckBox(f"-Keywords")
        keywords.setStyleSheet("color: #8b4513;")
        self.metadata_checkboxes.append(keywords)

        # Créer la checkbox pour les champs optionnels
        self.optional_checkbox = QCheckBox("Effectuer un rattachement à une autre unité archivistique")
        self.optional_checkbox.setStyleSheet("color: #8b4513;")
        self.optional_checkbox.stateChanged.connect(self.toggle_optional_fields)

        # Créer les widgets pour les champs de texte optionnels
        self.rattachement_label = QLabel("Cote de l'UA de rattachement :")
        self.rattachement_label.setStyleSheet("color: #8b4513;")
        self.rattachement_input = QLineEdit()

        self.nom_rattachement_label = QLabel("Nom de l'UA de rattachement :")
        self.nom_rattachement_label.setStyleSheet("color: #8b4513;")
        self.nom_rattachement_input = QLineEdit()

        # Initialement, les champs optionnels ne sont pas visibles
        self.rattachement_label.setVisible(False)
        self.rattachement_input.setVisible(False)
        self.nom_rattachement_label.setVisible(False)
        self.nom_rattachement_input.setVisible(False)

        # Boutons pour sélectionner répertoires et fichiers
        self.entree_dir_button = QPushButton("Sélectionner Répertoire d'entrée")
        self.entree_dir_button.setStyleSheet("color: #8b4513;")
        self.entree_dir_button.clicked.connect(self.select_entree_dir)
        self.entree_dir_label = QLabel("Aucun répertoire sélectionné")
        self.entree_dir_label.setStyleSheet("color: #8b4513;")

        self.cible_dir_button = QPushButton("Sélectionner Répertoire cible")
        self.cible_dir_button.setStyleSheet("color: #8b4513;")
        self.cible_dir_button.clicked.connect(self.select_cible_dir)
        self.cible_dir_label = QLabel("Aucun répertoire sélectionné")
        self.cible_dir_label.setStyleSheet("color: #8b4513;")

        self.csv_file_button = QPushButton("Sélectionner Fichier CSV")
        self.csv_file_button.setStyleSheet("color: #8b4513;")
        self.csv_file_button.clicked.connect(self.select_csv_file)
        self.csv_file_label = QLabel("Aucun fichier CSV sélectionné")
        self.csv_file_label.setStyleSheet("color: #8b4513;")

        self.txt_file_button = QPushButton("Sélectionner Fichier Texte")
        self.txt_file_button.setStyleSheet("color: #8b4513;")
        self.txt_file_button.clicked.connect(self.select_txt_file)
        self.txt_file_label = QLabel("Aucun fichier texte sélectionné")
        self.txt_file_label.setStyleSheet("color: #8b4513;")

        # Créer un bouton de soumission
        self.submit_button = QPushButton("Soumettre")
        self.submit_button.setStyleSheet("background-color: #ff8c00; color: white;")
        self.submit_button.clicked.connect(self.submit)
        self.submit_button.setEnabled(False)  # Initialement désactivé

        # Créer un layout en grille pour organiser les widgets
        grid_layout = QGridLayout()
        grid_layout.addWidget(intro_label, 0, 0, 1, 3, alignment=Qt.AlignmentFlag.AlignCenter)
        grid_layout.addWidget(self.num_entree, 1, 0)
        grid_layout.addWidget(self.entree_input, 1, 1)
        grid_layout.addWidget(self.num_paquet, 2, 0)
        grid_layout.addWidget(self.paquet_input, 2, 1)
        grid_layout.addWidget(self.versement_label, 3, 0)
        grid_layout.addWidget(self.versement_input, 3, 1)
        grid_layout.addWidget(self.archival_agency_identifier_label, 4, 0)
        grid_layout.addWidget(self.archival_agency_identifier_input, 4, 1)
        grid_layout.addWidget(self.transferring_agency_identifier_label, 5, 0)
        grid_layout.addWidget(self.transferring_agency_identifier_input, 5, 1)
        grid_layout.addWidget(self.originating_agency_identifier_label, 6, 0)
        grid_layout.addWidget(self.originating_agency_identifier_input, 6, 1)
        grid_layout.addWidget(self.submission_agency_identifier_label, 7, 0)
        grid_layout.addWidget(self.submission_agency_identifier_input, 7, 1)
        grid_layout.addWidget(self.authorized_agent_activity_label, 8, 0)
        grid_layout.addWidget(self.authorized_agent_activity_input, 8, 1)
        grid_layout.addWidget(self.authorized_agent_mandate_label, 9, 0)
        grid_layout.addWidget(self.authorized_agent_mandate_input, 9, 1)
        grid_layout.addWidget(self.archival_profile_label, 10, 0)
        grid_layout.addWidget(self.archival_profile_input, 10, 1)
        grid_layout.addWidget(self.acquisition_information_label, 11, 0)
        grid_layout.addWidget(self.acquisition_information_input, 11, 1)
        grid_layout.addWidget(self.legal_status_label, 12, 0)
        grid_layout.addWidget(self.legal_status_input, 12, 1)

        # Ajouter les cases à cocher pour les métadonnées
        metadata_label = QLabel("Métadonnées internes à extraire :")
        metadata_label.setStyleSheet("color: #8b4513;")
        grid_layout.addWidget(metadata_label, 13, 0, 1, 3, alignment=Qt.AlignmentFlag.AlignCenter)

        row = 14
        col = 0
        for checkbox in self.metadata_checkboxes:
            grid_layout.addWidget(checkbox, row, col)
            col += 1
            if col == 3:
                col = 0
                row += 1

        # Ajouter la checkbox optionnelle et les champs optionnels
        grid_layout.addWidget(self.optional_checkbox, row + 1, 0, 1, 3, alignment=Qt.AlignmentFlag.AlignCenter)
        grid_layout.addWidget(self.rattachement_label, row + 2, 0)
        grid_layout.addWidget(self.rattachement_input, row + 2, 1)
        grid_layout.addWidget(self.nom_rattachement_label, row + 3, 0)
        grid_layout.addWidget(self.nom_rattachement_input, row + 3, 1)

        # Ajouter les boutons pour sélectionner les répertoires et fichiers
        grid_layout.addWidget(self.entree_dir_button, row + 4, 0)
        grid_layout.addWidget(self.entree_dir_label, row + 4, 1)
        grid_layout.addWidget(self.cible_dir_button, row + 5, 0)
        grid_layout.addWidget(self.cible_dir_label, row + 5, 1)
        grid_layout.addWidget(self.csv_file_button, row + 6, 0)
        grid_layout.addWidget(self.csv_file_label, row + 6, 1)
        grid_layout.addWidget(self.txt_file_button, row + 7, 0)
        grid_layout.addWidget(self.txt_file_label, row + 7, 1)

        # Ajouter le bouton Soumettre en bas, centré
        grid_layout.addWidget(self.submit_button, row + 8, 0, 1, 3, alignment=Qt.AlignmentFlag.AlignCenter)

        # Créer un widget pour le contenu principal et définir le layout
        main_widget = QWidget()
        main_widget.setLayout(grid_layout)

        # Créer une zone de défilement pour le widget principal
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setWidget(main_widget)

        self.setCentralWidget(scroll_area)

        # Connecter la vérification des champs obligatoires
        self.entree_input.textChanged.connect(self.check_fields)
        self.paquet_input.textChanged.connect(self.check_fields)
        self.versement_input.textChanged.connect(self.check_fields)
        self.archival_agency_identifier_input.textChanged.connect(self.check_fields)
        self.transferring_agency_identifier_input.textChanged.connect(self.check_fields)
        self.originating_agency_identifier_input.textChanged.connect(self.check_fields)
        self.submission_agency_identifier_input.textChanged.connect(self.check_fields)
        self.authorized_agent_activity_input.textChanged.connect(self.check_fields)
        self.authorized_agent_mandate_input.textChanged.connect(self.check_fields)
        self.archival_profile_input.textChanged.connect(self.check_fields)
        self.acquisition_information_input.textChanged.connect(self.check_fields)
        self.legal_status_input.textChanged.connect(self.check_fields)

        # Vérifier les champs au démarrage de l'application
        self.check_fields()

    def check_fields(self):
        # Vérifier si tous les champs obligatoires sont remplis pour activer le bouton Soumettre
        mandatory_fields = [
            self.entree_input, self.paquet_input, self.versement_input,
            self.transferring_agency_identifier_input, self.originating_agency_identifier_input,
            self.submission_agency_identifier_input, self.authorized_agent_activity_input,
            self.authorized_agent_mandate_input, self.archival_profile_input,
            self.acquisition_information_input, self.legal_status_input
        ]

        for field in mandatory_fields:
            if field.text().strip() == "":
                self.submit_button.setEnabled(False)
                return

        self.submit_button.setEnabled(True)

    def toggle_optional_fields(self):
        # Afficher ou cacher les champs optionnels en fonction de l'état de la checkbox
        is_checked = self.optional_checkbox.isChecked()
        self.rattachement_label.setVisible(is_checked)
        self.rattachement_input.setVisible(is_checked)
        self.nom_rattachement_label.setVisible(is_checked)
        self.nom_rattachement_input.setVisible(is_checked)

    def select_entree_dir(self):
        directory = QFileDialog.getExistingDirectory(self, "Sélectionner Répertoire d'entrée")
        if directory:
            self.entree_dir_label.setText(directory)

    def select_cible_dir(self):
        directory = QFileDialog.getExistingDirectory(self, "Sélectionner Répertoire cible")
        if directory:
            self.cible_dir_label.setText(directory)

    def select_csv_file(self):
        file, _ = QFileDialog.getOpenFileName(self, "Sélectionner Fichier CSV", "", "CSV Files (*.csv)")
        if file:
            self.csv_file_label.setText(file)

    def select_txt_file(self):
        file, _ = QFileDialog.getOpenFileName(self, "Sélectionner Fichier Texte", "", "Text Files (*.txt)")
        if file:
            self.txt_file_label.setText(file)

    def submit(self):
        # Récupérer les valeurs des champs de texte
        entree_dir = self.entree_dir_label.text()
        cible_dir = self.cible_dir_label.text()
        csv_file = self.csv_file_label.text()
        txt_file = self.txt_file_label.text()

        data = {
            "Num_entree": self.entree_input.text(),
            "Num_paquet": self.paquet_input.text(),
            "Versement": self.versement_input.text(),
            "ArchivalAgency_Identifier": self.archival_agency_identifier_input.text(),
            "TransferringAgency_Identifier": self.transferring_agency_identifier_input.text(),
            "OriginatingAgency_Identifier": self.originating_agency_identifier_input.text(),
            "SubmissionAgency_Identifier": self.submission_agency_identifier_input.text(),
            "AuthorizedAgent_Actvity": self.authorized_agent_activity_input.text(),
            "AuthorizedAgent_Mandate": self.authorized_agent_mandate_input.text(),
            "ArchivalProfile": self.archival_profile_input.text(),
            "AcquisitionInformation": self.acquisition_information_input.text(),
            "Legal_Status": self.legal_status_input.text(),
            "Rattachement": [
                self.rattachement_input.text() if self.rattachement_input.isVisible() else "N/A",
                self.nom_rattachement_input.text() if self.nom_rattachement_input.isVisible() else "N/A"
            ],
            "Champs_metadata": [checkbox.text() for checkbox in self.metadata_checkboxes if checkbox.isChecked()],
            "dir_path": entree_dir,
            "cible": cible_dir,
            "csv": csv_file,
            "liste_rp": txt_file
        }

        # Afficher les valeurs dans la console (ou effectuer une autre action)
        print("Formulaire soumis avec succès !")
        print(json.dumps(data, indent=4))

        return data

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
