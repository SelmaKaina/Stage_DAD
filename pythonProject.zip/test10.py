import subprocess
from tkinter import filedialog
import json
import os
import shutil
import csv
from string import printable
import re
from string import ascii_letters, digits
from exiftool import ExifTool
import os
import sys
from pathlib import Path
from exiftool import ExifTool
import logging
import chardet

def exif_extract(dir_path, liste_rp):
    """
    Utilise la librairie PyExiftool pour extraire les métadonnées internes des photos.
    :param str dir_path: le chemin vers le répertoire "racine" contenant les reportages.
    :param list liste_rp: la liste des numéros des reportages à ajouter au SIP.

    :return: list[dict] - une liste de dictionnaires, chaque dictionnaire contenant les métadonnées extraites
    pour un fichier.
    """
    data = []  # Initialisation de la liste qui va contenir les métadonnées extraites
    processed_files = set()  # Pour garder une trace des fichiers déjà traités
    dir_path = Path(dir_path)  # Utilisation de Path pour manipuler les chemins

    # Utilisation de PyExiftool pour extraire les métadonnées internes des photographies
    with ExifTool() as et:
        for rp in liste_rp:  # Parcours de chaque numéro de reportage dans la liste
            # Si un numéro de reportage de la liste n'est pas identifié dans les noms de dossier, interrompre le script
            if rp.lower() not in str([item.name.lower() for item in dir_path.iterdir()]):
                input(f"ERREUR : Le reportage {rp} n'a pas été trouvé dans le répertoire {dir_path}.")
                sys.exit("ANNULATION")

            for item in dir_path.iterdir():  # Parcours de chaque élément dans le répertoire racine
                item_name = item.name.lower()
                # Vérification si le nom de dossier contient un numéro de reportage
                if str(rp + " ").lower() in item_name or item_name.endswith(rp.lower()):
                    item_path = str(item.resolve())  # Chemin complet vers le dossier ou fichier

                    # Extraction des métadonnées spécifiques pour les fichiers du dossier
                    logging.info(f"Processing item: {item_path}")
                    exif_data_list = et.execute_json(
                        '-r', '-b', '-FileName', '-CreateDate', '-By-line', '-Artist',
                        '-City', '-Country', '-Country-PrimaryLocationName', '-Description', '-Subject',
                        '-Keywords', '-FileModifyDate', '-Filesize#', item_path
                    )

                    for dict in exif_data_list:
                        for key in dict:
                            value = dict[key]
                            if isinstance(value, list):
                                for i in value:
                                    result = chardet.detect(i.encode("latin1"))
                                    encoding = result['encoding']
                                    print(encoding)
                                    value_decoded = []
                                    if encoding == "ISO-8859-9" or encoding == "MacRoman":
                                        i.encode("latin1").decode('utf-8')
                                        value_decoded.append(i)
                                        dict[key] = value_decoded
                            elif isinstance(value, str):
                                result = chardet.detect(value.encode("latin1"))
                                encoding = result['encoding']
                                print(encoding)
                                if encoding == "ISO-8859-9" or encoding == "MacRoman":
                                    dict[key] = value.encode("latin1").decode('utf-8')
                    # Vérification si le fichier a déjà été traité pour éviter les doublons
                    if item_path in processed_files:
                        continue  # Passer au prochain fichier si celui-ci a déjà été traité

                    # Si des métadonnées sont extraites, les ajouter à la liste des données
                    if exif_data_list:
                        data.extend(exif_data_list)
                        processed_files.add(item_path)  # Ajouter le fichier à la liste des fichiers traités


    return data  # Retourner la liste des métadonnées extraites pour tous les fichiers concernés

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Exemple d'utilisation
dir_path = "C:\\Users\selma.bensidhoum\Desktop\TEST_Hollandé_2015"
liste_rp = ["130478"]
result = exif_extract(dir_path, liste_rp)
#print(result)


"""
def select_directory():
    input()
    dir_path = filedialog.askdirectory()
    print(dir_path)
    return dir_path

def select_list_rp():
    Sélectionne le fichier texte contenant les numéros des reportages à ajouter au SIP.

    :return: list - la liste des numéros des reportages à analyser.
    
    input("Appuyez sur Entrée pour sélectionner le fichier txt contenant la liste des reportages à ajouter au paquet.")
    list_rp = filedialog.askopenfilename()
    my_file = open(list_rp, "r")
    data = my_file.read()
    # Fichier texte transformé en liste en transformant chaque retour à la ligne en virgule
    data_into_list = data.replace('\n', ',').split(",")
    return data_into_list

def siegfried(dir_path, liste_rp):
    
    Utilise l'outil Siegfried pour extraire les métadonnées de format des fichiers.
    :param str dir_path: le chemin vers le répertoire "racine" contenant les reportages.
    :param list liste_rp: la liste des numéros des reportages à analyser.

    :return: list[dict] - une liste de dictionnaires contenant les métadonnées de format des fichiers.
    
    format_rp = []  # Liste qui va contenir les métadonnées de format des fichiers par reportage
    # Parcours de chaque numéro de reportage dans la liste
    for rp in liste_rp:
        # Parcours de chaque élément (fichier ou dossier) dans le répertoire racine
        for item in os.listdir(dir_path):
            if str(rp+" ").lower() in item.lower() or item.lower().endswith(rp.lower()):
                print("Extraction Siegfried : " + item)
                item_path = os.path.join(dir_path, item)  # Chemin complet vers le dossier ou fichier
                # Appel à Siegfried pour obtenir les métadonnées de format au format JSON
                md_format = subprocess.run(["sf", "-hash", "sha512", "-json", item_path], capture_output=True,
                                           text=True, encoding="utf-8")
                md_format = json.loads(md_format.stdout)  # Conversion de la sortie JSON en dictionnaire Python
                format_rp.append(md_format)
                print("Traitement du dossier "+item+" terminé")  # Ajouter le fichier à la liste des fichiers traités
                # Ajout des métadonnées de format pour ce reportage à la liste

    # Correction des chemins de fichier dans chaque dictionnaire de métadonnées de format
    for rp in format_rp:
        fichiers = rp.get("files", [])   # Récupération de la liste des fichiers dans les métadonnées du reportage
        for file in fichiers:
            # Remplacement des séparateurs de chemin Windows par des slashs
            file["filename"] = file["filename"].replace("\\", "/")

    return format_rp  # Retourne la liste de dictionnaires contenant les métadonnées de format des reportages analysés

dir_path = select_directory()
list = select_list_rp()

i = siegfried(dir_path, list)

for rp in i:
    fichiers = rp.get("files", [])  # Récupération de la liste des fichiers dans les métadonnées du reportage
    for file in fichiers:
        # Remplacement des séparateurs de chemin Windows par des slashs
        print(file["sha512"])


def measure(dir_path):
    spechar = ["  ", " - ", "--", "’", ""]
    for item in os.listdir(dir_path):
        item_path = os.path.join(dir_path, item)
        if len(item_path) > 205:
            print(item_path + "contient" + str(len(item_path)) + "caractères")
        for char in spechar:
            if char in item_path:
                print("Le reportage" + item_path + "contient le caractère :" + char)
        if os.path.isdir(item_path):
            measure(item_path)




def exif_extract(dir_path):
    data = subprocess.run(['exiftool', '-r', '-b', '-FileName', '-CreateDate', '-By-line', '-City', '-Country',
                        '-Country-PrimaryLocationName', '-Caption-Abstract', '-Subject', '-Artist',
                        '-FileModifyDate', '-Filesize#', '-charset', 'utf8', dir_path], capture_output=True, text=True)
    return data

def updateoperation():
    user_input = input("Voulez-vous rattacher ce paquet à une autre unité archivistique ? (Oui/Non): ")
    if user_input.lower() in ["oui", "o"]:
        UA = input("Entrez la valeur de la balise 'ArchivalAgencyArchiveUnitIdentifier' de l'UA de rattachement.")
        return UA
    else:
        print("D'accord, passons à la suite...")


data = updateoperation()
print(data)





def select_list_rp():
    list_rp = filedialog.askopenfilename()
    with open(list_rp, "r") as my_file:
        data = my_file.read()
    data_into_list = data.replace('\n', ',').split(",")
    return data_into_list





def siegfried(dir_path, liste_rp):
    format_rp = []
    for rp in liste_rp:
        for item in os.listdir(dir_path):
            if rp in item:
                item_path = os.path.join(dir_path, item)
                md_format = subprocess.run(["sf", "-hash", "sha512", "-json", item_path], capture_output=True, text=True)
                md_format = json.loads(md_format.stdout)
                format_rp.append(md_format)

    for rp in format_rp:
        fichiers = rp.get("files", [])
        for file in fichiers:
            file["filename"] = file["filename"].replace("\\", "/")

    return format_rp

def metadata_json(data1, data2):
    new_data = []

    for rp in data1:
        files = rp.get("files", [])
        for file in files:
            filename = file["filename"]
            for item in data2:
                if item.get("SourceFile") == filename:
                    file.update(item)
        new_data.append({'files': files})

    return new_data

dir = select_directory()
liste = select_list_rp()
data_exif = exif_extract(dir, liste)
data_sf = siegfried(dir, liste)
data = metadata_json(data_sf, data_exif)
print(data)


#print(json.dumps(data, ensure_ascii=False, indent=4))


def exif_extract(dir_path, liste_rp):
    data = []
    processed_files = set()  # Pour garder une trace des fichiers déjà traités
    with ExifTool() as et:
        for rp in liste_rp:
            for item in os.listdir(dir_path):
                if rp in item:
                    item_path = os.path.join(dir_path, item)
                    if item_path in processed_files:
                        continue  # Passer au prochain fichier si celui-ci a déjà été traité
                    exif_data_list = et.execute_json(*['-r', '-b', '-FileName', '-CreateDate', '-By-line', '-City', '-Country',
                                                       '-Country-PrimaryLocationName', '-Caption-Abstract', '-Subject', '-Artist',
                                                       '-FileModifyDate', '-Filesize#', '-charset'] + ['utf8'] + [item_path])
                    if exif_data_list:
                        data.extend(exif_data_list)
                        processed_files.add(item_path)  # Ajouter le fichier à la liste des fichiers traités
    return data








def siegfried(dir_path):
    md_format = subprocess.run(["sf", "-hash", "sha512", "-json", dir_path], capture_output=True, text=True)
    md_format = json.loads(md_format.stdout)
    return md_format







dir = select_directory()
liste = select_list_rp()
data = exif_extract(dir, liste)
for info in data:
    print(info.get("File:FileName", "Nom de fichier non trouvé"))




directory = select_directory()
for dirpath, dirnames, filenames in os.walk(directory):
    if "1" in dirpath:
        for item in filenames:
            if "1200060356" in item:
                print(item)


text = "02 Entretien PR"
091298 Déco COLLECTIVE (21) -AALB-



dir_path = select_directory()
for item in os.listdir(dir_path):
    item_path = os.path.join(dir_path, item)
    for c in item:
        if not 0 <= ord(c) <= 65535:
        #if set(item).difference(ascii_letters + digits):
            #new_item = re.sub("[^A-Za-z0-9éèçêâîô\\'\\(\\)\\s]+", "_", item)
            print(item)



def select_list_rp():
    list_rp = filedialog.askopenfilename()
    my_file = open(list_rp, "r")
    data = my_file.read()
    data_into_list = data.replace('\n', ',').split(",")
    return data_into_list

liste_rp = select_list_rp()
print(liste_rp)


# Select the source directory
def select_directory():
    print("Bonjour ! Appuyez sur Entrée pour choisir un dossier.")
    input()
    dir_path = filedialog.askdirectory()
    return dir_path

# Choose the target directory and create the 'content' subdirectory
def chose_target_dir():
    print("Choisir le répertoire cible.")
    input()
    target_dir = filedialog.askdirectory()
    content = 'content'
    path = os.path.join(target_dir, content)
    if not os.path.exists(path):
        os.mkdir(path)
    return path

# Copy and rename files according to CSV instructions
def copy(dir_path, target_dir, csv_data):
    for item in os.listdir(dir_path):
        item_path = os.path.join(dir_path, item)
        for row in csv_data:
            if row[0] in item_path:
                if os.path.isdir(item_path):
                    copy(item_path, target_dir, csv_data)
                elif os.path.isfile(item_path) and "DS_Store" not in item and "Thumbs" not in item:
                    shutil.copy(item_path, os.path.join(target_dir, item))


# Select the CSV file
def select_csv():
    print("Choisir un fichier CSV.")
    input()
    csv_path = filedialog.askopenfilename()
    return csv_path

# Read the CSV file
def lire_ir_csv(csv_path):
    data_ir = []
    with open(csv_path, newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter=';')
        for row in reader:
            data_ir.append(row)
    return data_ir

# Main execution
if __name__ == "__main__":
    dir_path = select_directory()
    csv_path = select_csv()
    csv_data = lire_ir_csv(csv_path)
    target_dir = chose_target_dir()
    copy_rename(dir_path, target_dir, csv_data)




def siegfried(dir_path):
    md_format = subprocess.run(["sf", "-hash", "sha512", "-json", dir_path], capture_output=True, text=True)
    md_format = json.loads(md_format.stdout)
    return md_format

selected_dir = select_directory()
md_format = siegfried(selected_dir)
fichiers = md_format["files"]
print(fichiers)


def id_attrib(arbre):
    root = arbre
    descrmd = root.find("DescriptiveMetadata")
    AUs = descrmd.findall(".//ArchiveUnit")
    id = 0
    for AU in AUs:
        id = id+1
        AU.set("id", "AU"+id)
    return root
"""